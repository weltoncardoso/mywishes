package br.com.weltoncardoso.desejos.atps.mywishes.DOMINIO;

import java.io.Serializable;

/**
 * Created by welton cardoso and Alex on 23/03/2016.
 */
public class Desejos implements Serializable {
    private static  final long serialVersionUID = 1L;
    private long id;
    private String nome;
    private String categoria;
    private float precominimo;
    private float precomaximo;
    private String lojas;


    @Override
    public String toString(){

        return nome;
    }


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }


    public String getLojas() {
        return lojas;
    }

    public void setLojas(String lojas) {
        this.lojas = lojas;
    }


    public float getPrecominimo() {
        return precominimo;
    }

    public void setPrecominimo(float precominimo) {
        this.precominimo = precominimo;
    }

    public float getPrecomaximo() {
        return precomaximo;
    }

    public void setPrecomaximo(float precomaximo) {
        this.precomaximo = precomaximo;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

}
