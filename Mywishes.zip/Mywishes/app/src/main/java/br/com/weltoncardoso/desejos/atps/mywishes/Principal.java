package br.com.weltoncardoso.desejos.atps.mywishes;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

import br.com.weltoncardoso.desejos.atps.mywishes.DAO.DesejosDAO;
import br.com.weltoncardoso.desejos.atps.mywishes.DOMINIO.Desejos;
import br.com.weltoncardoso.desejos.atps.mywishes.TELAS.AlterarDesejo;
import br.com.weltoncardoso.desejos.atps.mywishes.TELAS.DetalhesDesejo;
import br.com.weltoncardoso.desejos.atps.mywishes.TELAS.InserirDesejos;

public class Principal extends AppCompatActivity {

    private Desejos desejoClicado;
    private Desejos desejo;
    private ListView lista;
    private Toolbar mToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(" DESEJOS");
        toolbar.setSubtitle("Lista dos meus desejos!");
        toolbar.setLogo(R.drawable.ic_gift_white_48dp);
        setSupportActionBar(toolbar);
        lista = (ListView) findViewById(R.id.lista);


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivityForResult(new Intent(Principal.this,
                        InserirDesejos.class), -1);
            }
        });
        registerForContextMenu(lista);


        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {

                Desejos desejoClicado = (Desejos) adapter.getItemAtPosition(position);

                Intent IrParaDetalhes = new Intent(Principal.this,DetalhesDesejo.class);

                IrParaDetalhes.putExtra("DesejoSelecionado", desejoClicado);

                startActivity(IrParaDetalhes);

            }
        });

        lista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            @Override
            public boolean onItemLongClick(AdapterView<?> adapter, View view, int position, long id) {

                desejoClicado = (Desejos) adapter.getItemAtPosition(position);

                desejo = (Desejos) adapter.getItemAtPosition(position);

                return false;
            }
        });
    }


    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        MenuItem alterar = menu.add("Alterar");
        alterar.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Intent IrParaDetalhes = new Intent(Principal.this,AlterarDesejo.class);
                IrParaDetalhes.putExtra("DesejoSelecionado2", desejoClicado);

                startActivity(IrParaDetalhes);
                return false;
            }
        });

        MenuItem deletar = menu.add("Deletar");

        deletar.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {
                DesejosDAO dao = new DesejosDAO(Principal.this);
                dao.deletar(desejo);
                Toast.makeText(getBaseContext(), "Excluido Com Sucesso !!!", Toast.LENGTH_SHORT).show();
                dao.close();
                carregaLista();
                return false;

            }
        });



        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    protected void onResume() {
        carregaLista();
        super.onResume();
    }

    private void carregaLista(){
        DesejosDAO dao = new DesejosDAO(this);

        List<Desejos> desejos = dao.getLista();
        dao.close();

        int layout = android.R.layout.simple_list_item_checked;

        ArrayAdapter<Desejos> adapter = new ArrayAdapter<Desejos>(this, layout , desejos);

        ListView lista = (ListView) findViewById(R.id.lista);
        lista.setAdapter(adapter);

    }


}