package br.com.weltoncardoso.desejos.atps.mywishes.BD;

import android.widget.EditText;
import android.widget.TextView;

import br.com.weltoncardoso.desejos.atps.mywishes.DOMINIO.Desejos;
import br.com.weltoncardoso.desejos.atps.mywishes.R;
import br.com.weltoncardoso.desejos.atps.mywishes.TELAS.AlterarDesejo;
import br.com.weltoncardoso.desejos.atps.mywishes.TELAS.DetalhesDesejo;
import br.com.weltoncardoso.desejos.atps.mywishes.TELAS.InserirDesejos;

/**
 * Created by welton cardoso and Alex on 23/03/2016.
 */
public class InserirDesejosHelper {

    private EditText editNome;
    private EditText editCategoria;
    private EditText editprecoMinimo;
    private EditText editprecoMaximo;
    private EditText editLojas;

    private TextView viewNome;
    private TextView viewCategoria;
    private TextView viewPrecoMinimo;
    private TextView viewPrecoMaximo;
    private TextView viewLojas;

// construtor inserir desejos
    public InserirDesejosHelper(InserirDesejos inserirDesejos) {

        editNome = (EditText) inserirDesejos.findViewById(R.id.txtProduto);
        editCategoria = (EditText) inserirDesejos.findViewById(R.id.txtCategoria);
        editprecoMinimo = (EditText) inserirDesejos.findViewById(R.id.txtPrecoMinimo);
        editprecoMaximo = (EditText) inserirDesejos.findViewById(R.id.txtPrecoMaximo);
        editLojas = (EditText) inserirDesejos.findViewById(R.id.txtlojas);


    }
//construtor detalhes do desejo
    public InserirDesejosHelper(DetalhesDesejo detalhesDesejo) {
        viewNome = (TextView) detalhesDesejo.findViewById(R.id.nometext);
        viewCategoria = (TextView) detalhesDesejo.findViewById(R.id.categoriatext);
        viewPrecoMinimo = (TextView) detalhesDesejo.findViewById(R.id.precominimotext);
        viewPrecoMaximo = (TextView) detalhesDesejo.findViewById(R.id.precomaximotext);
        viewLojas = (TextView) detalhesDesejo.findViewById(R.id.lojatext);
    }


//alterar desejo

    public InserirDesejosHelper(AlterarDesejo alterarDesejo) {

        editNome = (EditText) alterarDesejo.findViewById(R.id.txtProduto);
        editCategoria = (EditText) alterarDesejo.findViewById(R.id.txtCategoria);
        editprecoMinimo = (EditText) alterarDesejo.findViewById(R.id.txtPrecoMinimo);
        editprecoMaximo = (EditText) alterarDesejo.findViewById(R.id.txtPrecoMaximo);
        editLojas = (EditText) alterarDesejo.findViewById(R.id.txtlojas);
    }

//inserir no banco

    public Desejos PegaDesejoDaLista() {

        Desejos desejos = new Desejos();

        desejos.setNome(editNome.getText().toString());
        desejos.setCategoria(editCategoria.getText().toString());
        desejos.setPrecominimo(Float.valueOf(editprecoMinimo.getText().toString()));
        desejos.setPrecomaximo(Float.valueOf(editprecoMaximo.getText().toString()));
        desejos.setLojas(editLojas.getText().toString());


        return desejos;
    }

    //construtor detalhes do desejo

    public void colocaDesejoNaTelaExibir(Desejos desejoParaSerExibido) {


        viewNome.setText(desejoParaSerExibido.getNome());
        viewCategoria.setText(desejoParaSerExibido.getCategoria());
        viewPrecoMinimo.setText(String.valueOf(desejoParaSerExibido.getPrecominimo()));
        viewPrecoMaximo.setText(String.valueOf(desejoParaSerExibido.getPrecomaximo()));
        viewLojas.setText(desejoParaSerExibido.getLojas());

    }

// construtor alterar desejo

    public void alterarDesejo(Desejos desejoParaSerAlterado) {

        editNome.setText(desejoParaSerAlterado.getNome());
        editCategoria.setText(desejoParaSerAlterado.getCategoria());
        editprecoMinimo.setText(String.valueOf(desejoParaSerAlterado.getPrecominimo()));
        editprecoMaximo.setText(String.valueOf(desejoParaSerAlterado.getPrecomaximo()));
        editLojas.setText(desejoParaSerAlterado.getLojas());
    }


}