package br.com.weltoncardoso.desejos.atps.mywishes.TELAS;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import br.com.weltoncardoso.desejos.atps.mywishes.BD.InserirDesejosHelper;
import br.com.weltoncardoso.desejos.atps.mywishes.DAO.DesejosDAO;
import br.com.weltoncardoso.desejos.atps.mywishes.DOMINIO.Desejos;
import br.com.weltoncardoso.desejos.atps.mywishes.Principal;
import br.com.weltoncardoso.desejos.atps.mywishes.R;


/**
 * Created by welton cardoso and Alex on 23/03/2016.
 */
public class InserirDesejos extends AppCompatActivity {
    private InserirDesejosHelper helper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.ic_gift_white_36dp);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        setContentView(R.layout.inserir_desejos);

        setTitle("  Inserir Desejo");

        helper = new InserirDesejosHelper(this);




    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemclicado = item.getItemId();
        switch (itemclicado){
            case R.id.salvar:
                Intent IrParaIserirDesejos = new Intent(this,Principal.class);
                startActivity(IrParaIserirDesejos);

                Desejos desejos = helper.PegaDesejoDaLista();
                DesejosDAO dao = new DesejosDAO(InserirDesejos.this);
                dao.salva(desejos);
                Toast.makeText(getBaseContext(), "Salvo Com Sucesso !!!", Toast.LENGTH_SHORT).show();
                dao.close();


                break;

            default:
                break;

        }
        return super.onOptionsItemSelected(item);
    }
    public void CadastrarClick (View v){

        EditText TxtProduto = (EditText) findViewById(R.id.txtProduto);
        EditText TxtCategoria = (EditText) findViewById(R.id.txtCategoria);
        EditText TxtPrecoMinimo = (EditText) findViewById(R.id.txtPrecoMinimo);
        EditText TxtPrecoMaximo = (EditText) findViewById(R.id.txtPrecoMaximo);
        EditText TxtLojas = (EditText) findViewById(R.id.txtlojas);



        try {
            if(TxtProduto.getText().toString().length() <=0){
                TxtProduto.setError("Preencha o campo Produto!");
                TxtProduto.requestFocus();
            } else if(TxtCategoria.getText().toString().length() <=0) {
                TxtCategoria.setError("Preencha o campo Categoria!");
                TxtCategoria.requestFocus();
            } else if(TxtPrecoMinimo.getText().toString().length() <=0) {
                TxtPrecoMinimo.setError("Preencha o campo Preco minimo!");
                TxtPrecoMinimo.requestFocus();
            } else if(TxtPrecoMaximo.getText().toString().length() <=0) {
                TxtPrecoMaximo.setError("Preencha o campo Preco maximo!");
                TxtPrecoMaximo.requestFocus();
            } else if(TxtLojas.getText().toString().length() <=0) {
                TxtLojas.setError("Preencha o campo Lojas!");
                TxtLojas.requestFocus();
            } else {
                SQLiteDatabase db = openOrCreateDatabase("Inserir Desejos", Context.MODE_PRIVATE, null);

                ContentValues ctv = new ContentValues();
                ctv.put("nome", TxtProduto.getText().toString());
                ctv.put("categoria", TxtCategoria.getText().toString());
                ctv.put("precominimo", TxtPrecoMinimo.getText().toString());
                ctv.put("precomaximo", TxtPrecoMaximo.getText().toString());
                ctv.put("lojas", TxtLojas.getText().toString());

                if (db.insert("Desejos", "_id", ctv) > 0) {
                    Toast.makeText(getBaseContext(), "Sucesso ao cadastrar o Produto!", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(getBaseContext(), "Erro ao cadastrar o produto!", Toast.LENGTH_SHORT).show();
                }
            }}catch (Exception ex){
            Toast.makeText(getBaseContext(), ex.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }};




