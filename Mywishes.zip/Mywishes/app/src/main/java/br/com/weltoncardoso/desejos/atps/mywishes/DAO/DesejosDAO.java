package br.com.weltoncardoso.desejos.atps.mywishes.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by welton cardoso and Alex on 23/03/2016.
 */

import br.com.weltoncardoso.desejos.atps.mywishes.DOMINIO.Desejos;

public class DesejosDAO extends SQLiteOpenHelper {

    private static final String DATABASE = "Inserir Desejos";
    private static final int VERSAO = 1;

    public DesejosDAO(Context context){


        super(context, DATABASE, null, VERSAO);
    }


    public void salva(Desejos desejos) {

        ContentValues values = new ContentValues();
        values.put("nome",desejos.getNome());
        values.put("categoria",desejos.getCategoria());
        values.put("precominimo",desejos.getPrecominimo());
        values.put("precomaximo",desejos.getPrecomaximo());
        values.put("lojas",desejos.getLojas());


        getWritableDatabase().insert("Desejos", null, values);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String ddl = "CREATE TABLE Desejos(id INTEGER PRIMARY KEY ,"+
                "nome VARCHAR(30) NOT NULL, categoria VARCHAR(3) NOT NULL," +
                "precominimo INTERGER(20) NOT NULL, precomaximo INTERGER(20) NOT NULL," +
                "lojas VARCHAR(30) NOT NULL);";
        db.execSQL(ddl);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String ddl = "DROP TABLE IF EXISTS Desejos ";
        db.execSQL(ddl);

        this.onCreate(db);
    }

    public List<Desejos> getLista() {

        String[] colunas = {"id", "nome", "categoria", "precominimo", "precomaximo", "lojas"};

        Cursor cursor = getWritableDatabase().query("Desejos",colunas, null, null, null, null, null);

        ArrayList<Desejos> desejos= new ArrayList<Desejos>();

        while (cursor.moveToNext()) {

            Desejos desejo = new Desejos();

            desejo.setId(cursor.getLong(0));
            desejo.setNome(cursor.getString(1));
            desejo.setCategoria(cursor.getString(2));
            desejo.setPrecominimo(cursor.getFloat(3));
            desejo.setPrecomaximo(cursor.getFloat(4));
            desejo.setLojas(cursor.getString(5));

            desejos.add(desejo);
        }

        return desejos ;

    }

    public void deletar(Desejos desejo) {

        getWritableDatabase().delete("Desejos", "id=?", new String[] {String.valueOf(desejo.getId())} );
    }


    public void altera(Desejos desejos) {

        ContentValues values = new ContentValues();
        values.put("nome",desejos.getNome());
        values.put("categoria",desejos.getCategoria());
        values.put("precominimo",desejos.getPrecominimo());
        values.put("precomaximo",desejos.getPrecomaximo());
        values.put("lojas",desejos.getLojas());

        getWritableDatabase().update("Desejos",values, "id=?", new String[] {String.valueOf(desejos.getId())} );
    }
}


