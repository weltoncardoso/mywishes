package br.com.weltoncardoso.desejos.atps.mywishes.TELAS;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import br.com.weltoncardoso.desejos.atps.mywishes.BD.InserirDesejosHelper;
import br.com.weltoncardoso.desejos.atps.mywishes.DAO.DesejosDAO;
import br.com.weltoncardoso.desejos.atps.mywishes.DOMINIO.Desejos;
import br.com.weltoncardoso.desejos.atps.mywishes.R;

/**
 * Created by welton cardoso and Alex on 23/03/2016.
 */

public class AlterarDesejo extends AppCompatActivity {
    private InserirDesejosHelper helper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.ic_gift_white_36dp);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        setContentView(R.layout.alterar_desejo);
        setTitle("  Alterar Desejo");


        Intent intent = getIntent();
        final Desejos desejoParaSerAlterado = (Desejos) intent.getSerializableExtra("DesejoSelecionado2");
        helper = new InserirDesejosHelper(this);

        if (desejoParaSerAlterado != null) {

            helper.alterarDesejo(desejoParaSerAlterado);
        }

        Button botao = (Button) findViewById(R.id.btnSalvar);

        assert botao != null;
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Desejos desejos = helper.PegaDesejoDaLista();

                DesejosDAO dao = new DesejosDAO(AlterarDesejo.this);
                desejos.setId(desejoParaSerAlterado.getId());
                dao.altera(desejos);

                if(desejoParaSerAlterado != null) {
                   Toast.makeText(getBaseContext(), "Desejo Alterado !!!", Toast.LENGTH_SHORT).show();
               }
                else if(desejoParaSerAlterado == null){
                    Toast.makeText(getBaseContext(), "Nada Foi Alterado !!!", Toast.LENGTH_SHORT).show();

               }
                dao.close();
                finish();
            }

        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        Intent intent = getIntent();
        final Desejos desejoParaSerAlterado = (Desejos) intent.getSerializableExtra("DesejoSelecionado2");
            findViewById( R.id.salvar);
        Desejos desejos = helper.PegaDesejoDaLista();
        DesejosDAO dao = new DesejosDAO(AlterarDesejo.this);

        desejos.setId(desejoParaSerAlterado.getId());
        dao.altera(desejos);

        dao.close();
        finish();

        return super.onOptionsItemSelected(item);
    }

}



