package br.com.weltoncardoso.desejos.atps.mywishes.TELAS;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import br.com.weltoncardoso.desejos.atps.mywishes.BD.InserirDesejosHelper;
import br.com.weltoncardoso.desejos.atps.mywishes.DOMINIO.Desejos;
import br.com.weltoncardoso.desejos.atps.mywishes.R;


/**
 * Created by welton cardoso and Alex on 23/03/2016.
 */
public class DetalhesDesejo extends AppCompatActivity {
    private Desejos desejoClicado;
    private InserirDesejosHelper helper;
    private Toolbar mToolbar;
    private Toolbar mToolbarBottom;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        setContentView(R.layout.detalhes_desejo);
        setTitle("  Detalhes Desejo");



        final Intent intent = getIntent();
        final Desejos desejoParaSerExibido = (Desejos) intent.getSerializableExtra("DesejoSelecionado");

        helper = new InserirDesejosHelper(this);

        if (desejoParaSerExibido != null) {
            helper.colocaDesejoNaTelaExibir(desejoParaSerExibido);
        }


        ImageView image = (ImageView) findViewById(R.id.buscape);
        assert image != null;
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                assert desejoParaSerExibido != null;
                Uri localSite = Uri.parse("http://buscape.com.br/" + desejoParaSerExibido.getCategoria() + "/" + desejoParaSerExibido.getNome());
                intent.setData(localSite);
                startActivity(intent);

            }
        });

                Button mercado = (Button) findViewById(R.id.btnMercado);
                mercado.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent();
                        intent.setAction(Intent.ACTION_VIEW);
                        intent.addCategory(Intent.CATEGORY_BROWSABLE);
                        assert desejoParaSerExibido != null;
                        Uri localSite = Uri.parse("http://lista.mercadolivre.com.br/"+desejoParaSerExibido.getCategoria()+"/"+desejoParaSerExibido.getNome());
                        intent.setData(localSite);
                        startActivity(intent);
            }
        });


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.lista,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        final Intent intent = getIntent();
        final Desejos desejoParaSerExibido = (Desejos) intent.getSerializableExtra("DesejoSelecionado");

        int itemclicado = item.getItemId();
        switch (itemclicado){
            case R.id.novo:
                Intent it = new Intent(Intent.ACTION_SEND);
                it.setType("text/plain");
                it.putExtra(Intent.EXTRA_TEXT, "http://lista.mercadolivre.com.br/"
                            +desejoParaSerExibido.getCategoria()+"/"+desejoParaSerExibido.getNome());
                it.putExtra(Intent.EXTRA_SUBJECT, "welton");
                startActivity(Intent.createChooser(it, "compartilhar!"));
                break;

            default:
                break;


        }
        return super.onOptionsItemSelected(item);
    }
}